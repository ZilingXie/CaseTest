import { AzureFunction, Context, HttpRequest } from "@azure/functions"
import * as msRestAzure from "ms-rest-azure";
import { ResourceManagementClient  } from "@azure/arm-resources";
import { NetworkManagementClient , SecurityRule } from '@azure/arm-network';
import { Durations , LogsQueryClient, MetricsQueryClient , LogsTable , LogsQuerySuccessfulResult } from "@azure/monitor-query";


const { DefaultAzureCredential } = require("@azure/identity");
const workspaceId = "YourLogAnalyticsWorkSpaceID"; // 這請加上Log Analytics的WorspaceID 
const kustoQuery = `
    AzureDiagnostics
    | where ResourceType == "APPLICATIONGATEWAYS" and OperationName == "ApplicationGatewayAccess"
    | summarize AggregatedValue = count() by clientIP_s
    | where AggregatedValue > 10000
    | project clientIP_s
`

const rgName = "YourResourceGroupName" ; // 這要改 
const nsgName = "YourNSGName"; // 這也要改
const policyName = "YourNSGPolicyName" ; // 這還是要改 

function onlyUnique(value, index, self) {
    return self.indexOf(value) === index;
}

const httpTrigger: AzureFunction = async function (context: Context, req: HttpRequest): Promise<void> {
    context.log('HTTP trigger function processed a request.');
    const credential = new DefaultAzureCredential();

    const subscriptionId = 'YourSubID'; // 這請加上Azure訂閱ID

    const resourceClient = new ResourceManagementClient(credential, subscriptionId);

    const networkClient = new NetworkManagementClient(credential, subscriptionId);

   
    let nsg = await networkClient.networkSecurityGroups.get(rgName , nsgName);
    
    const logsQueryClient = new LogsQueryClient(credential);
    //query table
    const queryResult = ( await logsQueryClient.queryWorkspace(workspaceId, kustoQuery, {
        duration: Durations.twentyFourHours
    }) ) as LogsQuerySuccessfulResult

    if(queryResult.tables.length < 0){
        context.res = {
            body : "no query result"
        }
        return ; 
    }

    let blockTarget = queryResult.tables [0].rows.reduce((a , b )=>{
        return a.concat(b[0]) ;
    }, []).filter(onlyUnique) as string[]

    
    //create if not exist
    let error = "" as any ;
    try {
        nsg = {
            ...nsg ,
            securityRules : [
                ...nsg.securityRules.filter(x=>x.name !== policyName) ,
                {
                    name : "perlpolicy" , 
                    access : "Deny" ,
                    destinationAddressPrefix : "*" ,
                    direction : "Inbound" ,
                    destinationPortRange : "443" ,
                    priority : 100 ,
                    protocol : "Tcp" ,
                    sourceAddressPrefixes :blockTarget,
                    sourcePortRange : "*"

                }
            ]
        }
        await networkClient.networkSecurityGroups.beginCreateOrUpdateAndWait(rgName , nsgName , nsg);
    }catch(e){
        error = e ; 
    }
   

   


    //const name = (req.query.name || (req.body && req.body.name));
    
    context.res = {
        // status: 200, /* Defaults to 200 */
        body: {
            msg : "ok" ,
            //nsg , 
            //kusto : blockTarget , 
            //error 
        }
    };

};

export default httpTrigger;